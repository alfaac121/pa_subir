<?php
echo "<h2>Tu cuenta está bloqueada. Contacta al administrador.</h2>";
exit;
?>

